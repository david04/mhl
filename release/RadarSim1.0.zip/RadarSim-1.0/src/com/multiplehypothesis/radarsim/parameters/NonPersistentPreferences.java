package com.multiplehypothesis.radarsim.parameters;

import java.util.HashMap;
import java.util.prefs.AbstractPreferences;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;
import java.util.prefs.PreferencesFactory;
import org.apache.log4j.Logger;

/**
 *
 * @author David Miguel Antunes <davidmiguel [ at ] antunes.net>
 */
public class NonPersistentPreferences implements PreferencesFactory {

    private static final Logger logger = Logger.getLogger(NonPersistentPreferences.class);

    private static class Node extends AbstractPreferences {

        public Node(Node parent, String name) {
            super(parent, name);
        }
        private HashMap<String, String> map = new HashMap<String, String>();
        private HashMap<String, AbstractPreferences> childreen = new HashMap<String, AbstractPreferences>();

        @Override
        protected void putSpi(String key, String value) {
            map.put(key, value);
        }

        @Override
        protected String getSpi(String key) {
            return map.get(key);
        }

        @Override
        protected void removeSpi(String key) {
            map.remove(key);
        }

        @Override
        protected void removeNodeSpi() throws BackingStoreException {
            ((Node) parent()).childreen.remove(name());
        }

        @Override
        protected String[] keysSpi() throws BackingStoreException {
            return map.keySet().toArray(new String[0]);
        }

        @Override
        protected String[] childrenNamesSpi() throws BackingStoreException {
            return childreen.keySet().toArray(new String[0]);
        }

        @Override
        protected AbstractPreferences childSpi(String name) {
            if (!childreen.containsKey(name)) {
                childreen.put(name, new Node(this, name));
            }
            return childreen.get(name);
        }

        @Override
        protected void syncSpi() throws BackingStoreException {
        }

        @Override
        protected void flushSpi() throws BackingStoreException {
        }
    }
    private static Preferences userRoot = new Node(null, "");
    private static Preferences systemRoot = new Node(null, "");

    public Preferences systemRoot() {
        return systemRoot;
    }

    public Preferences userRoot() {
        return userRoot;
    }
}
