package com.multiplehypothesis.radarsim.tracker;

import eu.anorien.mhl.Event;
import eu.anorien.mhl.Fact;
import eu.anorien.mhl.Factory;
import eu.anorien.mhl.HypothesesManager;
import eu.anorien.mhl.Hypothesis;
import eu.anorien.mhl.MHLService;
import eu.anorien.mhl.MayBeRequiredPredicate;
import eu.anorien.mhl.Watcher;
import eu.anorien.mhl.lisbonimpl.extras.visualization.ClusterVisualizer;
import eu.anorien.mhl.lisbonimpl.extras.visualization.LeafVisualizer;
import eu.anorien.mhl.pruner.Pruner;
import com.multiplehypothesis.radarsim.parameters.Parameters;
import com.multiplehypothesis.radarsim.Target;
import com.multiplehypothesis.radarsim.parameters.Groups;
import com.multiplehypothesis.radarsim.tracker.events.TargetMovedEvent;
import com.multiplehypothesis.radarsim.tracker.events.TrackInitiatedEvent;
import com.multiplehypothesis.radarsim.tracker.events.TrackTerminatedEvent;
import com.multiplehypothesis.radarsim.tracker.events.TrackingEvent;
import com.multiplehypothesis.radarsim.tracker.facts.TargetPositionFact;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ServiceLoader;
import org.apache.log4j.Logger;

/**
 *
 * @author David Miguel Antunes <davidmiguel [ at ] antunes.net>
 */
public class Tracker {

    private static final Logger logger = Logger.getLogger(Tracker.class);
    public static boolean SAVE_HISTORY = true;
    private static final int TARGET_SIZE = 10;
    private static final int TRACK_SIZE = 4;
    private static boolean CLUSTERING_ENABLED = true;
    private static boolean SHOW_PREDICTED_POSITION = true;
    private static int MAX_NUM_LEAVES = 10;
    private static int MAX_TAIL_SIZE = 10;
    private static Factory factory;
    private static HypothesesManager manager;
    private HypothesesGeneratorWatcher watcher;
    private HypothesisGenerator generator;
    private ClusterVisualizer clusterVisualizer;
    private LeafVisualizer leafVisualizer;
    private long dt;
    private long processingTime;
    private final ArrayList<Event> confirmedEvents = new ArrayList<Event>();
    private long currentTime;

    {
        ServiceLoader<MHLService> serviceLoader = ServiceLoader.load(MHLService.class);
        factory = serviceLoader.iterator().next().getFactory();
        manager = factory.newHypothesesManager();
    }

    public static void registerParams() {
        Parameters.instance.registerInt(Groups.noGroup, Target.class, "NUM_LEAVES", "Max #leaves=$VAL", 1, 50, new Parameters.ParameterChangeListener<Integer>() {

            public void parameterChanged(Integer val) {
                MAX_NUM_LEAVES = val;
                if (manager != null) {
                    manager.setPruner(factory.getPrunerFactory().newCompositePruner(
                            new Pruner[]{
                                factory.getPrunerFactory().newBestKPruner(MAX_NUM_LEAVES),
                                factory.getPrunerFactory().newTreeDepthPruner(MAX_TAIL_SIZE)
                            }));
                }
            }
        });
        Parameters.instance.registerInt(Groups.noGroup, Target.class, "MAX_TAIL_SIZE", "Max tail size=$VAL", 1, 50, new Parameters.ParameterChangeListener<Integer>() {

            public void parameterChanged(Integer val) {
                MAX_TAIL_SIZE = val;
                if (manager != null) {
                    manager.setPruner(factory.getPrunerFactory().newCompositePruner(
                            new Pruner[]{
                                factory.getPrunerFactory().newBestKPruner(MAX_NUM_LEAVES),
                                factory.getPrunerFactory().newTreeDepthPruner(MAX_TAIL_SIZE)
                            }));
                }
            }
        });
        Parameters.instance.registerBoolean(Groups.noGroup, Tracker.class, "SAVEHIST", "History enabled ", new Parameters.ParameterChangeListener<Boolean>() {

            public void parameterChanged(Boolean val) {
                SAVE_HISTORY = val;
            }
        });
        Parameters.instance.registerBoolean(Groups.visualization, Target.class, "SHOW_PREDICTED", "Show predicted target position ", new Parameters.ParameterChangeListener<Boolean>() {

            public void parameterChanged(Boolean val) {
                SHOW_PREDICTED_POSITION = val;
            }
        });
//        Parameters.instance.registerBoolean(Groups.noGroup, Target.class, "CLUSTER_ENABLED", "Clustering enabled ", new Parameters.ParameterChangeListener<Boolean>() {
//
//            public void parameterChanged(Boolean val) {
//                if (manager != null) {
//                    manager.setClusteringEnabled(val);
//                }
//                CLUSTERING_ENABLED = val;
//            }
//        });
    }

    public Tracker(long dt) {
        this.dt = dt;
//        manager.setClusteringEnabled(CLUSTERING_ENABLED);
        clusterVisualizer = new ClusterVisualizer(manager);
        clusterVisualizer.getLeafVisualizer().setVisible(true);
        clusterVisualizer.setVisible(true);
        leafVisualizer = clusterVisualizer.getLeafVisualizer();
        watcher = new HypothesesGeneratorWatcher();
        generator = new HypothesisGenerator(factory, manager, watcher, dt);
        manager.setPruner(factory.getPrunerFactory().newCompositePruner(new Pruner[]{
                    factory.getPrunerFactory().newBestKPruner(MAX_NUM_LEAVES),
                    factory.getPrunerFactory().newTreeDepthPruner(MAX_TAIL_SIZE)}));
        manager.register(watcher);
        manager.setRequiredPredicate(new MayBeRequiredPredicate() {

            public boolean mayBeRequired(Event event) {
                return false;
            }

            public boolean mayBeRequired(Fact fact) {
                return (fact instanceof TargetPositionFact);
            }
        });
        manager.register(new Watcher() {

            public void newFact(Fact fact) {
            }

            public void newFacts(Collection<Fact> facts) {
            }

            public void removedFact(Fact fact) {
            }

            public void removedFacts(Collection<Fact> facts) {
            }

            public void newEvent(Event event) {
            }

            public void newEvents(Collection<Event> events) {
            }

            public void removedEvent(Event event) {
            }

            public void removedEvents(Collection<Event> events) {
            }

            public void confirmedEvent(Event event) {
                synchronized (confirmedEvents) {
                    confirmedEvents.add(event);
                }
            }

            public void confirmedEvents(Collection<Event> events) {
                synchronized (confirmedEvents) {
                    confirmedEvents.addAll(events);
                }
            }

            public void bestHypothesis(Hypothesis hypothesis) {
            }
        });
    }

    public void newScan(List<Measurement> measurements, long time) {
        currentTime = time;
        long t = System.currentTimeMillis();
        generator.newScan(measurements, time);
        t = System.currentTimeMillis() - t;
        processingTime = t;
    }

    public Map<TargetPositionFact, Double> bestHypotheses() {
        Map<TargetPositionFact, Double> hyp = new HashMap<TargetPositionFact, Double>();
        for (Map.Entry<Fact, Double> entry : manager.getBestHypothesis().getFacts().entrySet()) {
            hyp.put((TargetPositionFact) entry.getKey(), entry.getValue().doubleValue());
        }
        return hyp;
    }

    public void paintTargets(Graphics g) {
//        paintAllHypotheses(g);
        paintBestHypothesis(g);
    }

    private void paintEvent(Event e, Graphics g) {
        if (e instanceof TrackInitiatedEvent) {
            TrackInitiatedEvent event = (TrackInitiatedEvent) e;
            g.fillRect(((int) event.getX()) - TRACK_SIZE / 2, ((int) event.getY()) - TRACK_SIZE / 2, TRACK_SIZE, TRACK_SIZE);
        } else if (e instanceof TrackTerminatedEvent) {
            TrackTerminatedEvent event = (TrackTerminatedEvent) e;
        } else if (e instanceof TargetMovedEvent) {
            TargetMovedEvent event = (TargetMovedEvent) e;
            g.drawLine(
                    (int) event.getX1(),
                    (int) event.getY1(),
                    (int) event.getX2(),
                    (int) event.getY2());
            g.fillRect(
                    ((int) event.getX2()) - TRACK_SIZE / 2,
                    ((int) event.getY2()) - TRACK_SIZE / 2,
                    TRACK_SIZE,
                    TRACK_SIZE);
        }
    }

    public void paintTracks(Graphics g) {
        for (Event e : manager.getBestHypothesis().getEvents().keySet()) {
            paintEvent(e, g);
        }
        synchronized (confirmedEvents) {
            for (Event event : confirmedEvents) {
                if (currentTime - ((TrackingEvent) event).getTimestamp() < 10000) {
                    paintEvent(event, g);
                }
            }
        }
    }

    private void paintBestHypothesis(Graphics g) {
        for (Fact fact : manager.getBestHypothesis().getFacts().keySet()) {
            TargetPositionFact target = (TargetPositionFact) (Object) fact;
            double heading = Math.atan2((target.getPredictedY() - target.getY()), (target.getPredictedX() - target.getX()));
            Target.draw(g, target.getX(), target.getY(), heading);
            if (SHOW_PREDICTED_POSITION) {
                paintPredictedPosition(g, target);
            }
        }
    }

    private void paintPredictedPosition(Graphics g, TargetPositionFact target) {
        Color c = g.getColor();
        g.setColor(Color.red);
        g.fillPolygon(new int[]{(int) target.getPredictedX() - TARGET_SIZE / 2, (int) target.getPredictedX(), (int) target.getPredictedX() + TARGET_SIZE / 2, (int) target.getPredictedX()}, new int[]{(int) target.getPredictedY(), (int) target.getPredictedY() + TARGET_SIZE / 2, (int) target.getPredictedY(), (int) target.getPredictedY() - TARGET_SIZE / 2}, 4);
        g.setColor(c);
    }

    public long getProcessingTime() {
        return processingTime;
    }

    public ClusterVisualizer getClusterVisualizer() {
        return clusterVisualizer;
    }

    public LeafVisualizer getLeafVisualizer() {
        return leafVisualizer;
    }

    public HypothesesManager getManager() {
        return manager;
    }

    public HypothesisGenerator getHypothesisGenerator() {
        return generator;
    }
}
