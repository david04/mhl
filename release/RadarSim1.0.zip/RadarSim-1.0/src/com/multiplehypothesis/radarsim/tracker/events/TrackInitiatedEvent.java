package com.multiplehypothesis.radarsim.tracker.events;

import eu.anorien.mhl.Event;
import org.apache.log4j.Logger;

/**
 *
 * @author David Miguel Antunes <davidmiguel [ at ] antunes.net>
 */
public class TrackInitiatedEvent extends TrackingEvent implements Event {

    private static final Logger logger = Logger.getLogger(TrackInitiatedEvent.class);
    private final double x, y;
    private final long targetId;

    public TrackInitiatedEvent(long timestamp, double x, double y, long targetId) {
        super(timestamp);
        this.x = x;
        this.y = y;
        this.targetId = targetId;
    }

    public long getTargetId() {
        return targetId;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TrackInitiatedEvent other = (TrackInitiatedEvent) obj;
        if (Double.doubleToLongBits(this.x) != Double.doubleToLongBits(other.x)) {
            return false;
        }
        if (Double.doubleToLongBits(this.y) != Double.doubleToLongBits(other.y)) {
            return false;
        }
        if (this.targetId != other.targetId) {
            return false;
        }
        if (this.timestamp != other.timestamp) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 83 * hash + (int) (this.timestamp ^ (this.timestamp >>> 32));
        hash = 83 * hash + (int) (Double.doubleToLongBits(this.x) ^ (Double.doubleToLongBits(this.x) >>> 32));
        hash = 83 * hash + (int) (Double.doubleToLongBits(this.y) ^ (Double.doubleToLongBits(this.y) >>> 32));
        hash = 83 * hash + (int) (this.targetId ^ (this.targetId >>> 32));
        return hash;
    }
}
