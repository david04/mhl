package com.multiplehypothesis.radarsim.tracker.events;

import org.apache.log4j.Logger;

/**
 *
 * @author David Miguel Antunes <davidmiguel [ at ] antunes.net>
 */
public abstract class TrackingEvent {

    private static final Logger logger = Logger.getLogger(TrackingEvent.class);
    protected final long timestamp;

    public TrackingEvent(long timestamp) {
        this.timestamp = timestamp;
    }

    public long getTimestamp() {
        return timestamp;
    }
}
