package com.multiplehypothesis.radarsim;

import com.multiplehypothesis.radarsim.parameters.Groups;
import com.multiplehypothesis.radarsim.parameters.Parameters;
import static java.lang.Math.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Polygon;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import org.apache.log4j.Logger;

/**
 *
 * @author David Miguel Antunes <davidmiguel [ at ] antunes.net>
 */
public class RadarPanel extends GenericRadarPanel {

    private static final Logger logger = Logger.getLogger(RadarPanel.class);
    protected static boolean NOISE_ENABLED = false;
    protected static int AVERAGE_NOISE_DETECTIONS_PER_SCAN = 20;
    protected static final int ARTIFACT_SIZE = 10;
    /*
     * Turns per second.
     */
    protected static final double GREEN_LIGHT_SPEED = 0.5;
    protected static final double GREEN_LIGHT_TICKNESS = ((2 * PI) / 360) * 2;
    protected static boolean SAME_COLORS = true;
    protected final Set<Target> targets;
    protected long time = 0;
    protected double greenLightAngle = 0;
    protected SortedMap<Double, GroundTruth.RadarArtifact> cacheAngles = new TreeMap<Double, GroundTruth.RadarArtifact>();
    protected Random random;
    protected GroundTruth gt;

    public static void registerParams() {
        Parameters.instance.registerInt(Groups.noGroup, RadarPanel.class, "AVRGNOISE", "Avrg noise artifacts=$VAL", 0, 60, new Parameters.ParameterChangeListener<Integer>() {

            public void parameterChanged(Integer val) {
                AVERAGE_NOISE_DETECTIONS_PER_SCAN = val;
            }
        });
        Parameters.instance.registerBoolean(Groups.noGroup, RadarPanel.class, "NOISEENABLES", "Noise enabled: ", new Parameters.ParameterChangeListener<Boolean>() {

            public void parameterChanged(Boolean val) {
                NOISE_ENABLED = val;
            }
        });
        Parameters.instance.registerBoolean(Groups.noGroup, RadarPanel.class, "SAMECOLORS", "All artifact same color: ", new Parameters.ParameterChangeListener<Boolean>() {

            public void parameterChanged(Boolean val) {
                SAME_COLORS = val;
            }
        });
    }

    public RadarPanel(int width, int height, Set<Target> targets, Random random, GroundTruth gt) {
        super(width, height);
        this.targets = targets;
        this.random = random;
        this.gt = gt;
    }

    @Override
    protected synchronized void doPaint(Graphics g) {
        paintWhite(g);
        for (GroundTruth.TargetArtifact s : gt.targetCache.values()) {
            s.painter.paint(g);
        }
        for (GroundTruth.TargetArtifact s : gt.falseAlarmCache) {
            s.painter.paint(g);
        }
        for (GroundTruth.NoiseArtifact noiseArtifact : gt.noiseCache) {
            noiseArtifact.painter.paint(g);
        }
        paintGrid(g);
        paintGreenLight(g);
        paintBlack(g);
        paintMessages(g);
    }

    protected void paintGreenLight(Graphics g) {
        g.setColor(Color.green);
        Polygon p = new Polygon();
        p.addPoint(getWidth() / 2 - 1, getHeight() / 2 - 1);
        p.addPoint(
                getWidth() / 2 - 1 + (int) (cos(greenLightAngle) * max(getWidth() / 2, getHeight() / 2)),
                getHeight() / 2 - 1 + (int) (sin(greenLightAngle) * max(getWidth() / 2, getHeight() / 2)));
        p.addPoint(
                getWidth() / 2 - 1 + (int) (cos(greenLightAngle + GREEN_LIGHT_TICKNESS) * max(getWidth() / 2, getHeight() / 2)),
                getHeight() / 2 - 1 + (int) (sin(greenLightAngle + GREEN_LIGHT_TICKNESS) * max(getWidth() / 2, getHeight() / 2)));
        g.fillPolygon(p);
    }

    @Override
    public void step(long millis) {
        double oldGreenLightAngle = greenLightAngle;
        oldGreenLightAngle = updateRadar(millis, oldGreenLightAngle);
        if (greenLightAngle < oldGreenLightAngle) {
//                printStatus();
            gt.zeroDegrees(time);
        }
        msgs = new String[]{
                    "#targets:" + gt.targetCache.size(),
                    "noise:" + gt.noiseCache.size(),
                    "F.A.:" + gt.falseAlarmCache.size(),};
    }

    private double updateRadar(long millis, double oldGreenLightAngle) {
        synchronized (this) {
            time += millis;
            synchronized (targets) {
                greenLightAngle = (greenLightAngle + 2 * PI * GREEN_LIGHT_SPEED * (millis / 1000d)) % (2 * PI);
                if (greenLightAngle < oldGreenLightAngle) {
                    Map<Double, GroundTruth.RadarArtifact> subMap;
                    subMap = cacheAngles.subMap(oldGreenLightAngle, 2 * PI);
                    removeRadarArtifacts(subMap);
                    subMap.clear();
                    subMap = cacheAngles.subMap(0d, greenLightAngle);
                    removeRadarArtifacts(subMap);
                    subMap.clear();
                } else {
                    Map<Double, GroundTruth.RadarArtifact> subMap;
                    subMap = cacheAngles.subMap(oldGreenLightAngle, greenLightAngle);
                    removeRadarArtifacts(subMap);
                    subMap.clear();
                }
                HashSet<Target> targetsToConsider = new HashSet<Target>(targets);
                for (GroundTruth.TargetArtifact targetArtifact : gt.falseAlarmCache) {
                    targetsToConsider.add(targetArtifact.target);
                }
                for (Target target : targets) {
                    double oldTargetAngle = (atan2(-(target.getLastX() - getWidth() / 2d - 1), target.getLastY() - getHeight() / 2d - 1) + 2 * PI + PI / 2) % (2 * PI);
                    double targetAngle = (atan2(-(target.getX() - getWidth() / 2d - 1), target.getY() - getHeight() / 2d - 1) + 2 * PI + PI / 2) % (2 * PI);
                    double tmpOldTargetAngle = oldTargetAngle;
                    double tmpTargetAngle = targetAngle;
                    double tmpOldGreenLightAngle = oldGreenLightAngle;
                    double tmpGreenLightAngle = greenLightAngle;
                    if (abs(tmpOldTargetAngle - tmpTargetAngle) > PI || abs(tmpOldGreenLightAngle - tmpGreenLightAngle) > PI) {
                        tmpOldTargetAngle = (tmpOldTargetAngle + PI) % (2 * PI);
                        tmpTargetAngle = (tmpTargetAngle + PI) % (2 * PI);
                        tmpOldGreenLightAngle = (tmpOldGreenLightAngle + PI) % (2 * PI);
                        tmpGreenLightAngle = (tmpGreenLightAngle + PI) % (2 * PI);
                        if (abs(tmpOldTargetAngle - tmpTargetAngle) > PI || abs(tmpOldGreenLightAngle - tmpGreenLightAngle) > PI) {
                            tmpOldTargetAngle = (tmpOldTargetAngle + PI / 2) % (2 * PI);
                            tmpTargetAngle = (tmpTargetAngle + PI / 2) % (2 * PI);
                            tmpOldGreenLightAngle = (tmpOldGreenLightAngle + PI / 2) % (2 * PI);
                            tmpGreenLightAngle = (tmpGreenLightAngle + PI / 2) % (2 * PI);
                        }
                    }
                    if ((tmpOldTargetAngle < (tmpOldGreenLightAngle) && tmpTargetAngle > (tmpOldGreenLightAngle)) || ((tmpOldTargetAngle >= (tmpOldGreenLightAngle)) && tmpTargetAngle < (tmpGreenLightAngle))) {
                        detectTarget(target, targetAngle);
                    }
                }
                if (NOISE_ENABLED) {
                    oldGreenLightAngle = introduceNoise(oldGreenLightAngle);
                }
                super.step(millis);
            }
        }
        return oldGreenLightAngle;
    }

    private void printStatus() {
        System.out.println("");
        for (GroundTruth.TargetArtifact targetArtifact : gt.targetCache.values()) {
            System.out.println(targetArtifact.target.getId() + " -> " + "(" + targetArtifact.x + "," + targetArtifact.y + ")");
        }
        for (GroundTruth.NoiseArtifact noise : gt.noiseCache) {
            System.out.println("noise -> " + "(" + noise.x + "," + noise.y + ")");
        }
        for (GroundTruth.TargetArtifact targetArtifact : gt.falseAlarmCache) {
            System.out.println("FA(" + targetArtifact.target.getId() + ") -> " + "(" + targetArtifact.x + "," + targetArtifact.y + ")");
        }
    }

    private void removeRadarArtifacts(Map<Double, GroundTruth.RadarArtifact> subMap) {
        for (GroundTruth.RadarArtifact a : subMap.values()) {
            if (a instanceof GroundTruth.TargetArtifact) {
                GroundTruth.TargetArtifact ta = (GroundTruth.TargetArtifact) a;
                if (ta.falseAlarm) {
                    gt.falseAlarmCache.remove(ta);
                } else {
                    gt.targetCache.remove(((GroundTruth.TargetArtifact) a).target);
                }
            } else if (a instanceof GroundTruth.NoiseArtifact) {
                gt.noiseCache.remove((GroundTruth.NoiseArtifact) a);
            }
        }
    }

    private double introduceNoise(double oldGreenLightAngle) {
        double step;
        if (greenLightAngle < oldGreenLightAngle) {
            step = (2 * PI - oldGreenLightAngle) + greenLightAngle;
        } else {
            step = greenLightAngle - oldGreenLightAngle;
        }
        double expectedDetections = AVERAGE_NOISE_DETECTIONS_PER_SCAN * (step / (2 * PI));
//        int numNoiseDetections = (int) (max(0, random.nextGaussian() * 0.2 + expectedDetections));
        int numNoiseDetections = random.nextDouble() < expectedDetections ? 1 : 0;

        for (int i = 0; i < numNoiseDetections; i++) {
            double angle = oldGreenLightAngle + random.nextDouble() * (step);
            double radius = (1 - pow(random.nextDouble(), 2) * 0.9 + 0.1) * getWidth() / 2;
//            double radius = random.nextDouble() * getWidth() / 2;
            final int x = (int) (getWidth() / 2 + cos(angle) * radius);
            final int y = (int) (getHeight() / 2 + sin(angle) * radius);
            GroundTruth.NoiseArtifact noise = new GroundTruth.NoiseArtifact(new Painter() {

                public void paint(Graphics g) {
                    g.setColor(SAME_COLORS ? Color.BLACK : Color.RED.darker());
                    g.fillOval(x - ARTIFACT_SIZE / 2, y - ARTIFACT_SIZE / 2, ARTIFACT_SIZE, ARTIFACT_SIZE);
                }
            }, x, y);
            gt.noiseCache.add(noise);
            oldGreenLightAngle += 1 / 100000000000000d;
            if (cacheAngles.containsKey(oldGreenLightAngle)) {
                throw new RuntimeException();
            }
            cacheAngles.put(oldGreenLightAngle, noise);
        }
        return oldGreenLightAngle;
    }

    private double detectTarget(final Target target, double angle) {
        final GroundTruth.TargetArtifact a = new GroundTruth.TargetArtifact(null, target.getX(), target.getY(), target);
        a.painter = new Painter() {

            public void paint(Graphics g) {
                g.setColor(SAME_COLORS ? Color.BLACK : Color.GREEN.darker());
                g.fillOval(
                        (int) a.x - ARTIFACT_SIZE / 2,
                        (int) a.y - ARTIFACT_SIZE / 2,
                        ARTIFACT_SIZE,
                        ARTIFACT_SIZE);
            }
        };
        if (gt.targetCache.containsKey(target)) {
            gt.targetCache.get(target).falseAlarm = true;
            gt.falseAlarmCache.add(gt.targetCache.get(target));
        }
        gt.targetCache.put(target, a);
        if (cacheAngles.containsKey(angle)) {
            throw new RuntimeException();
        }
        cacheAngles.put(angle, a);
        return angle;
    }
}
