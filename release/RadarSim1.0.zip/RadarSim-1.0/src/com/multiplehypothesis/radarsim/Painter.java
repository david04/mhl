package com.multiplehypothesis.radarsim;

import java.awt.Graphics;

/**
 *
 * @author David Miguel Antunes <davidmiguel [ at ] antunes.net>
 */
public interface Painter {

    public void paint(Graphics g);
}
