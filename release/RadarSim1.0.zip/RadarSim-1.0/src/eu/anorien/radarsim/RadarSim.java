package eu.anorien.radarsim;

import eu.anorien.radarsim.parameters.Groups;
import eu.anorien.radarsim.parameters.Parameters;
import eu.anorien.radarsim.tracker.Tracker;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.WindowEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import static java.lang.Math.*;
import java.awt.HeadlessException;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowListener;
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;
import javax.swing.JFrame;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

/**
 *
 * @author David Miguel Antunes <davidmiguel [ at ] antunes.net>
 */
public class RadarSim {

    private static final Logger logger = Logger.getLogger(RadarSim.class);
    private static final int MAX_NEW_TARGETS = 1;
    private static final int RADAR_SIZE = 400;
    private static int OPTIMAL_NUM_TARGETS = 4;
    private static int MAX_TIME_OUT_OF_SIGHT = 2000;
    private static int SIMULATION_CLOCK = 10;
    private static int TIME_STEP_MILLIS = 30;
    private static int N_SIMULATION_STEPS = -1;
    private static boolean PAUSED = false;
    private final Set<Target> targets = new HashSet<Target>();
    private static final Preferences preferences = Preferences.userNodeForPackage(RadarSim.class);
    private Set<Target> onceVisible;
    private RadarPanel radar;
    private GroundTruthPanel groundTruthPanel;
    private TrackerPanel trackerPanel;
    private static Tracker tracker;
    private GroundTruth gt;
    private PerformanceAnalyzer performanceAnalyzer;
    private Random random = new Random(158634);

    static {
        try {
            RadarSim.class.getClassLoader().loadClass(Parameters.class.getName());
            RadarSim.class.getClassLoader().loadClass(Groups.class.getName());
            RadarSim.registerParams();
            Target.registerParams();
            GroundTruth.registerParams();
            RadarPanel.registerParams();
            PerformanceAnalyzer.registerParams();
            GenericRadarPanel.registerParams();
            Tracker.registerParams();
            Parameters.instance.tryLoadDefaultParameters();
        } catch (ClassNotFoundException ex) {
            logger.error(ex + " at " + ex.getStackTrace()[0].toString());
        }
    }

    public static void registerParams() {
        Parameters.instance.registerInt(Groups.noGroup, RadarSim.class, "NTARGETS", "Num targets=$VAL", 0, 500, new Parameters.ParameterChangeListener<Integer>() {

            public void parameterChanged(Integer val) {
                OPTIMAL_NUM_TARGETS = val;
            }
        });
        Parameters.instance.registerInt(Groups.noGroup, RadarSim.class, "MAXOUTOFSIGHT", "Max time out of sight=$VAL", 100, 5000, new Parameters.ParameterChangeListener<Integer>() {

            public void parameterChanged(Integer val) {
                MAX_TIME_OUT_OF_SIGHT = val;
            }
        });
        Parameters.instance.registerInt(Groups.noGroup, RadarSim.class, "SIMCLOCK", "Simulation clock=$VAL", 0, 100, new Parameters.ParameterChangeListener<Integer>() {

            public void parameterChanged(Integer val) {
                SIMULATION_CLOCK = val;
            }
        });
        Parameters.instance.registerInt(Groups.noGroup, RadarSim.class, "SIMSTEP", "Simulation resolution (step)=$VAL", 1, 100, new Parameters.ParameterChangeListener<Integer>() {

            public void parameterChanged(Integer val) {
                TIME_STEP_MILLIS = val;
                if (tracker != null) {
                    tracker.getHypothesisGenerator().setDt(val);
                }
            }
        });
        Parameters.instance.registerInt(Groups.noGroup, RadarSim.class, "N_SIMULATION_STEPS", "N simulation steps=$VAL", -1, 10000, new Parameters.ParameterChangeListener<Integer>() {

            public void parameterChanged(Integer val) {
                N_SIMULATION_STEPS = val;
            }
        });
        Parameters.instance.registerBoolean(Groups.noGroup, RadarSim.class, "PAUSED", "Pause ", new Parameters.ParameterChangeListener<Boolean>() {

            public void parameterChanged(Boolean val) {
                PAUSED = val;
            }
        });
        Parameters.instance.registerBoolean(Groups.visualization, RadarSim.class, "CLUSTVIS", "Show clusters visualizer ", new Parameters.ParameterChangeListener<Boolean>() {

            public void parameterChanged(Boolean val) {
                if (tracker != null) {
                    tracker.getClusterVisualizer().setVisible(val);
                }
            }
        });
        Parameters.instance.registerBoolean(Groups.visualization, RadarSim.class, "LEAFVIS", "Show leaf details ", new Parameters.ParameterChangeListener<Boolean>() {

            public void parameterChanged(Boolean val) {
                if (tracker != null) {
                    tracker.getLeafVisualizer().setVisible(val);
                }
            }
        });
    }

    public static void main(String[] args) throws IOException {
        BasicConfigurator.configure();
        Logger.getLogger("eu.anorien.mhl").setLevel(org.apache.log4j.Level.ERROR);
        String[] files = new String[]{
            null/*"parameters_input.txt"*/,};
        System.arraycopy(args, 0, files, 0, Math.min(args.length, files.length));
        new RadarSim().simulate(files[0]);
    }

    private void simulate(String parametersInput) throws IOException {
        onceVisible = new HashSet<Target>();
        groundTruthPanel = new GroundTruthPanel(RADAR_SIZE, RADAR_SIZE, targets);
        tracker = new Tracker(TIME_STEP_MILLIS);
        tracker.getHypothesisGenerator().setDt(TIME_STEP_MILLIS);
        gt = new GroundTruth(tracker);
        radar = new RadarPanel(RADAR_SIZE, RADAR_SIZE, targets, random, gt);
        trackerPanel = new TrackerPanel(RADAR_SIZE, RADAR_SIZE, tracker);

        if (parametersInput != null) {
            try {
                Parameters.instance.readFrom(new File(parametersInput).toURI().toURL());
            } catch (FileNotFoundException ex) {
                logger.error(ex + " at " + ex.getStackTrace()[0].toString());
            } catch (ClassNotFoundException ex) {
                logger.error(ex + " at " + ex.getStackTrace()[0].toString());
            }
        }

        final JFrame f0 = createFrame(radar, "RADAR");
        final JFrame f1 = createFrame(groundTruthPanel, "GROUND TRUTH");
        final JFrame f2 = createFrame(trackerPanel, "TRACKER");
        final JFrame f3 = Parameters.instance.showFrame();
        new Timer().schedule(new TimerTask() {

            @Override
            public void run() {
                for (JFrame frame : new JFrame[]{f0, f1, f2, f3, tracker.getClusterVisualizer(), tracker.getLeafVisualizer(), gt.getPerformanceAnalyzer().getPerformanceAnalyzerFrame()}) {
                    initWindowPosAndSize(frame);
                    trackWindowPosAndSize(frame);
                }
            }
        }, 100);
        tracker.getClusterVisualizer().setVisible((Boolean) Parameters.instance.get(this.getClass(), "CLUSTVIS"));
        tracker.getLeafVisualizer().setVisible((Boolean) Parameters.instance.get(this.getClass(), "LEAFVIS"));

        int steps = 0;
        TimerTask tt = new TimerTask() {

            @Override
            public void run() {
                if (!PAUSED) {
                    long t = System.currentTimeMillis();
                    synchronized (targets) {
                        for (Target target : targets) {
                            target.step(TIME_STEP_MILLIS);
                        }
                    }
                    radar.step(TIME_STEP_MILLIS);
                    groundTruthPanel.step(TIME_STEP_MILLIS);
                    trackerPanel.step(TIME_STEP_MILLIS);
                    synchronized (targets) {
                        manageTargets();
                    }
                    t = System.currentTimeMillis() - t;
//                    System.out.println("Elapsed: " + t);
                }
            }
        };

        while (true) {
            try {
                Thread.sleep(SIMULATION_CLOCK);
            } catch (InterruptedException ex) {
            }
            if (N_SIMULATION_STEPS != -1 && steps > N_SIMULATION_STEPS) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                }
                System.exit(0);
            }
            tt.run();
            steps++;
        }
    }

    public void manageTargets() {
        ArrayList<Target> toRemove = new ArrayList<Target>(0);
        for (Target target : targets) {
            if (!radar.visible(target)) {
                if (onceVisible.contains(target)) {
                    toRemove.add(target);
                } else if (target.getAge() > MAX_TIME_OUT_OF_SIGHT) {
                    toRemove.add(target);
                }
            }
            if (radar.visible(target)) {
                onceVisible.add(target);
            }
        }
        for (Target target : toRemove) {
            targets.remove(target);
            onceVisible.remove(target);
        }
        int nNewTargets = min(OPTIMAL_NUM_TARGETS - targets.size(), MAX_NEW_TARGETS);
        for (int i = 0; i < nNewTargets; i++) {
            double attackAngle = random.nextDouble() * 2 * PI;
            int x = radar.getWidth() / 2 + (int) (cos(attackAngle) * radar.getWidth() / 2 - 0);
            int y = radar.getWidth() / 2 + (int) (sin(attackAngle) * radar.getWidth() / 2 - 10);
            Target t = new Target(x, y, random.nextDouble() * 10, attackAngle + PI + random.nextDouble() * PI - (PI / 2), random);
            targets.add(t);
        }
    }

    private static JFrame createFrame(final Component generic, String name) throws HeadlessException {
        final JFrame frame = new JFrame(name);
        frame.getContentPane().add(generic);
        generic.setSize(RADAR_SIZE, RADAR_SIZE);
        generic.setPreferredSize(new Dimension(RADAR_SIZE, RADAR_SIZE));
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setResizable(false);
        return frame;
    }

    private static void initWindowPosAndSize(final JFrame frame) {
        EventQueue.invokeLater(new Runnable() {

            public void run() {
                if (frame.isResizable()) {
                    frame.setSize(
                            preferences.getInt(frame.getTitle() + ".width", frame.getPreferredSize().width),
                            preferences.getInt(frame.getTitle() + ".height", frame.getPreferredSize().height));
                }
                frame.setLocation(
                        preferences.getInt(frame.getTitle() + ".x", 0),
                        preferences.getInt(frame.getTitle() + ".y", 0));
            }
        });
    }

    private static void saveWindowPosAndSize(final JFrame frame) {
        if (frame.getLocationOnScreen().x == 0 || frame.getLocationOnScreen().y == 0) {
            return;
        }
        try {
            preferences.putInt(frame.getTitle() + ".width", frame.getSize().width);
            preferences.putInt(frame.getTitle() + ".height", frame.getSize().height);
            preferences.putInt(frame.getTitle() + ".x", frame.getLocationOnScreen().x);
            preferences.putInt(frame.getTitle() + ".y", frame.getLocationOnScreen().y);
        } catch (Exception e) {
        }
        try {
            preferences.flush();
        } catch (BackingStoreException ex) {
            logger.error(ex + " at " + ex.getStackTrace()[0].toString());
        }
    }

    private static void trackWindowPosAndSize(final JFrame frame) {
        frame.addWindowFocusListener(new WindowFocusListener() {

            public void windowGainedFocus(WindowEvent e) {
                saveWindowPosAndSize(frame);
            }

            public void windowLostFocus(WindowEvent e) {
                saveWindowPosAndSize(frame);
            }
        });
        frame.addWindowListener(new WindowListener() {

            private long check = 0;

            public void windowOpened(WindowEvent e) {
                change();
            }

            public void windowClosing(WindowEvent e) {
                change();
            }

            public void windowClosed(WindowEvent e) {
                change();
            }

            public void windowIconified(WindowEvent e) {
                change();
            }

            public void windowDeiconified(WindowEvent e) {
//                change();
            }

            public void windowActivated(WindowEvent e) {
                change();
            }

            public void windowDeactivated(WindowEvent e) {
                change();
            }

            private void change() {
                if (frame.getSize().hashCode() + frame.getLocationOnScreen().hashCode() != check) {
                    check = frame.getSize().hashCode() + frame.getLocationOnScreen().hashCode();
                    saveWindowPosAndSize(frame);
                }
            }
        });
    }
}
