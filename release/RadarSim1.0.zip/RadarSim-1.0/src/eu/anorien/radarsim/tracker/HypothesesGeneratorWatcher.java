package eu.anorien.radarsim.tracker;

import eu.anorien.mhl.Fact;
import eu.anorien.mhl.Hypothesis;
import eu.anorien.mhl.Watcher;
import eu.anorien.mhl.Event;
import java.util.Collection;
import java.util.HashSet;
import org.apache.log4j.Logger;

/**
 *
 * @author David Miguel Antunes <davidmiguel [ at ] antunes.net>
 */
public class HypothesesGeneratorWatcher implements Watcher {

    private static final Logger logger = Logger.getLogger(HypothesesGeneratorWatcher.class);
    private HashSet<Event> events;
    private HashSet<Fact> facts;

    public HypothesesGeneratorWatcher() {
        events = new HashSet<Event>();
        facts = new HashSet<Fact>();
    }

    public void newFact(Fact fact) {
        facts.add(fact);
    }

    public void removedFact(Fact fact) {
        facts.remove(fact);
    }

    public void newEvent(Event event) {
        events.add(event);
    }

    public void removedEvent(Event event) {
        events.remove(event);
    }

    public void confirmedEvent(Event event) {
        events.remove(event);
    }

    public void newFacts(Collection<Fact> facts) {
        for (Fact fact : facts) {
            newFact(fact);
        }
    }

    public void removedFacts(Collection<Fact> facts) {
        for (Fact fact : facts) {
            removedFact(fact);
        }
    }

    public void newEvents(Collection<Event> events) {
        for (Event event : events) {
            newEvent(event);
        }
    }

    public void removedEvents(Collection<Event> events) {
        for (Event event : events) {
            removedEvent(event);
        }
    }

    public void confirmedEvents(Collection<Event> events) {
        for (Event event : events) {
            confirmedEvent(event);
        }
    }

    public HashSet<Event> getEvents() {
        return events;
    }

    public HashSet<Fact> getFacts() {
        return facts;
    }

    public void bestHypothesis(Hypothesis hypothesis) {
    }
}
