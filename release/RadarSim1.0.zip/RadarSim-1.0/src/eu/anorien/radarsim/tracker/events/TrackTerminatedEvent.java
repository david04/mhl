package eu.anorien.radarsim.tracker.events;

import eu.anorien.mhl.Event;
import org.apache.log4j.Logger;

/**
 *
 * @author David Miguel Antunes <davidmiguel [ at ] antunes.net>
 */
public class TrackTerminatedEvent extends TrackingEvent implements Event {

    private static final Logger logger = Logger.getLogger(TrackTerminatedEvent.class);
    private final long targetId;

    public TrackTerminatedEvent(long timestamp, long targetId) {
        super(timestamp);
        this.targetId = targetId;
    }

    public long getTargetId() {
        return targetId;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TrackTerminatedEvent other = (TrackTerminatedEvent) obj;
        if (this.timestamp != other.timestamp) {
            return false;
        }
        if (this.targetId != other.targetId) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 43 * hash + (int) (this.timestamp ^ (this.timestamp >>> 32));
        hash = 43 * hash + (int) (this.targetId ^ (this.targetId >>> 32));
        return hash;
    }
}
