package eu.anorien.radarsim.tracker.facts;

import eu.anorien.mhl.Fact;
import com.the_lost_beauty.blogspot.kalman.KalmanFilter;
import org.apache.log4j.Logger;

/**
 *
 * @author David Miguel Antunes <davidmiguel [ at ] antunes.net>
 */
public class TargetPositionFact implements Fact, Cloneable {

    private static final Logger logger = Logger.getLogger(TargetPositionFact.class);
    private double x, y;
    private long targetId;
    private KalmanFilter kf;
    private long lastDetection;

    public TargetPositionFact(double x, double y, long targetId, KalmanFilter kf, long lastDetection) {
        this.x = x;
        this.y = y;
        this.targetId = targetId;
        this.kf = kf;
        this.lastDetection = lastDetection;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getPredictedX() {
        return kf.getX0().get(0, 0);
    }

    public double getPredictedY() {
        return kf.getX0().get(1, 0);
    }

    public KalmanFilter getKf() {
        return kf;
    }

    public long getTargetId() {
        return targetId;
    }

    public long getLastDetection() {
        return lastDetection;
    }

    public TargetPositionFact(double x, double y, long targetId, long lastDetection) {
        this.x = x;
        this.y = y;
        this.targetId = targetId;
        this.lastDetection = lastDetection;
    }

    @Override
    public String toString() {
        return "TargetPositionFact{" + "x=" + x + "y=" + y + "targetId=" + targetId + "lastDetection=" + lastDetection + '}';
    }

    @Override
    public Fact clone() {
        try {
            return (Fact) super.clone();
        } catch (CloneNotSupportedException ex) {
            return null;
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TargetPositionFact other = (TargetPositionFact) obj;
        if (Double.doubleToLongBits(this.x) != Double.doubleToLongBits(other.x)) {
            return false;
        }
        if (Double.doubleToLongBits(this.y) != Double.doubleToLongBits(other.y)) {
            return false;
        }
        if (this.targetId != other.targetId) {
            return false;
        }
        if (this.lastDetection != other.lastDetection) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 43 * hash + (int) (Double.doubleToLongBits(this.x) ^ (Double.doubleToLongBits(this.x) >>> 32));
        hash = 43 * hash + (int) (Double.doubleToLongBits(this.y) ^ (Double.doubleToLongBits(this.y) >>> 32));
        hash = 43 * hash + (int) (this.targetId ^ (this.targetId >>> 32));
        hash = 43 * hash + (int) (this.lastDetection ^ (this.lastDetection >>> 32));
        return hash;
    }
}
