package eu.anorien.radarsim.parameters;

import eu.anorien.radarsim.parameters.Parameters.Group;

/**
 *
 * @author David Miguel Antunes <davidmiguel [ at ] antunes.net>
 */
public class Groups {

    public static final Group noGroup = Parameters.instance.newGroup("No Group");
    public static final Group visualization = Parameters.instance.newGroup("Visualizations");
}
